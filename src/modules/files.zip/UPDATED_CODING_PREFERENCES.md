# Updated Coding Preferences for DraftProAnalytics

## Frontend Standards
- Framework: Vue 3 with Composition API exclusively
- Script style: Always use `<script setup lang="ts">`
- TypeScript: Strict mode enabled, never use 'any' types
- UI Library: PrimeVue components with PrimeIcons
- State Management: Pinia stores for all state
- Routing: Vue Router for navigation
- Build Tool: Vite
- HTTP Client: Axios for API calls
- Styling: Scoped styles, prefer CSS/SCSS
- Component structure: Composition API with composables for reusable logic

## Backend Standards
- Runtime: Node.js with TypeScript (strict mode)
- Framework: Express.js for REST APIs
- Database: MySQL
- ORM: Prisma (schema-first approach with `prisma db pull` + `prisma generate`)
- Environment: dotenv for configuration management
- Validation: Zod for runtime type validation
- Dependency Injection: **Manual DI using Container pattern** (no tsyringe)

## Architecture Principles
- Design Pattern: Domain-Driven Design (DDD)
- Code Organization: Modular Monolith (Package by Feature / Vertical Slice Architecture)
- SOLID Principles: Strictly enforced in all code
- No monolithic code blocks - functions must be concise and self-contained
- Separation of Concerns: Clear boundaries between layers

## Module Structure
```
src/modules/{moduleName}/
├── domain/                      # Business logic (pure, framework-agnostic)
│   ├── entities/                # Rich domain models with business logic
│   ├── value-objects/           # Immutable value types
│   ├── services/                # Domain services for complex business rules
│   └── repositories/            # Repository interfaces (I*Repository.ts)
├── application/                 # Use cases & orchestration
│   ├── dto/                     # Data Transfer Objects for API contracts
│   ├── services/                # Application services (use case implementations)
│   └── mappers/                 # Entity ↔ DTO transformations (optional)
├── infrastructure/              # External concerns & implementations
│   ├── repositories/            # Concrete repository implementations (Prisma)
│   ├── providers/               # External API integrations (ESPN, etc.)
│   └── di/                      # Dependency injection container
│       └── container.ts         # Manual DI container for the module
├── presentation/                # HTTP layer
│   ├── controllers/             # Request handlers
│   ├── validators/              # Request validation (Zod schemas)
│   └── routes/                  # Express route definitions
└── index.ts                     # Module bootstrap & public API
```

## Dependency Injection Pattern

### Manual Container Pattern (No tsyringe)

Each module has its own DI container:

```typescript
// container.ts
export class ModuleNameContainer {
  private static instance: ModuleNameContainer;
  
  // Singleton instances
  private _dependency?: DependencyType;
  
  private constructor() {}
  
  static getInstance(): ModuleNameContainer {
    if (!ModuleNameContainer.instance) {
      ModuleNameContainer.instance = new ModuleNameContainer();
    }
    return ModuleNameContainer.instance;
  }
  
  // Lazy initialization of dependencies
  getDependency(): DependencyType {
    if (!this._dependency) {
      this._dependency = new DependencyType(/* ... */);
    }
    return this._dependency;
  }
  
  // Setter for external dependencies (like PrismaClient)
  setExternalDependency(dep: ExternalType): void {
    this._externalDep = dep;
  }
  
  // Reset for testing
  reset(): void {
    this._dependency = undefined;
  }
}

export const getContainer = () => ModuleNameContainer.getInstance();
```

### Module Bootstrap Pattern

```typescript
// index.ts
export function bootstrapModuleName(prismaClient: PrismaClient): Router {
  const container = getContainer();
  container.setPrismaClient(prismaClient);
  
  const controller = container.getController();
  return createModuleRoutes(controller);
}
```

### Integration in Main App

```typescript
// app.ts
import { bootstrapModuleName } from './modules/moduleName';

const prisma = new PrismaClient();
const moduleRouter = bootstrapModuleName(prisma);
app.use('/api/module', moduleRouter);
```

## Shared Code Structure
```
src/shared/
├── domain/                      # Shared domain concepts
│   ├── entities/                # Base entity classes
│   ├── value-objects/           # Shared value objects
│   └── exceptions/              # Domain exceptions
├── application/                 # Shared application layer
│   └── interfaces/              # Common interfaces (IUseCase, etc.)
├── infrastructure/              # Shared infrastructure
│   ├── database/                # Database client setup
│   └── config/                  # Configuration management
└── types/                       # Shared TypeScript types
    └── common.ts                # Pagination, filters, etc.
```

## File Naming Conventions
- Entities: `*.entity.ts`
- Value Objects: `*.vo.ts`
- DTOs: `*.dto.ts`
- Services: `*.service.ts`
- Controllers: `*.controller.ts`
- Repository Interfaces: `I*Repository.ts`
- Repository Implementations: `Prisma*Repository.ts` or `*Repository.impl.ts`
- Routes: `*.routes.ts`
- Container: `container.ts`
- Module Bootstrap: `index.ts`

## Database Workflow

### Schema-First Approach
1. **DDL First**: Create/modify tables using MySQL DDL
2. **Pull Schema**: `npx prisma db pull` to sync Prisma schema
3. **Generate Client**: `npx prisma generate` to update Prisma client
4. **No Migrations**: Do not use Prisma migrations (`prisma migrate`)

### Example Workflow
```bash
# 1. Create table in MySQL
mysql> CREATE TABLE team_needs_analysis (...);

# 2. Pull schema from database
npx prisma db pull

# 3. Generate updated Prisma client
npx prisma generate

# 4. Use in code immediately
```

## Error Handling

```typescript
// Shared domain exceptions
export class DomainError extends Error {
  constructor(message: string) {
    super(message);
    this.name = this.constructor.name;
  }
}

export class NotFoundError extends DomainError {
  constructor(entity: string, id: number | string) {
    super(`${entity} with id ${id} not found`);
  }
}

export class ValidationError extends DomainError {}
export class ConflictError extends DomainError {}
```

## Testing Patterns

```typescript
describe('Service', () => {
  let container: Container;
  let service: Service;
  
  beforeEach(() => {
    container = new Container();
    container.setDependencies(/* ... */);
    service = container.getService();
  });
  
  afterEach(() => {
    container.reset();
  });
  
  it('should ...', async () => {
    // Test implementation
  });
});
```

## Key Differences from Default DDD

1. **No tsyringe**: Manual DI containers instead
2. **Schema-first**: Prisma schema driven by MySQL DDL
3. **Container per module**: Each feature has its own DI container
4. **Bootstrap pattern**: Modules export bootstrap functions
5. **Lazy initialization**: Dependencies created on first access

## Best Practices

- Keep domain layer pure (no framework dependencies)
- Use interfaces for all external dependencies
- Validate at boundaries (controllers, DTOs)
- Keep services thin - delegate to domain entities
- Use value objects for business concepts
- Return DTOs from application services, not entities
- Test domain logic without mocking
- Use manual DI for explicit dependency management
