# Team Needs Analysis Module

## Overview

The TeamNeedsAnalysis module automatically generates NFL draft needs based on roster depth analysis. It evaluates each team's personnel at every position and provides:

- **Position-by-position need scores** (0-100 scale)
- **Priority rankings** (1-10 scale) 
- **Detailed reasoning** for each identified need
- **Top priorities** (critical positions requiring immediate attention)
- **Overall team need score**

## Architecture

This module follows **Domain-Driven Design (DDD)** principles with clean separation of concerns:

```
src/modules/teamNeedsAnalysis/
├── domain/                          # Business logic layer
│   ├── entities/
│   │   └── TeamNeedsAnalysis.entity.ts
│   ├── value-objects/
│   │   └── PositionGroup.vo.ts
│   ├── services/
│   │   └── RosterAnalyzer.service.ts
│   └── repositories/
│       ├── ITeamNeedsAnalysisRepository.ts
│       ├── IRosterRepository.ts
│       └── IESPNRosterProvider.ts
├── application/                     # Use cases & orchestration
│   ├── dto/
│   │   └── TeamNeedsAnalysis.dto.ts
│   └── services/
│       └── TeamNeedsAnalysis.service.ts
├── infrastructure/                  # External concerns
│   ├── repositories/
│   │   ├── InMemoryTeamNeedsAnalysisRepository.ts
│   │   └── PrismaRosterRepository.ts
│   ├── providers/
│   │   └── ESPNRosterProvider.ts
│   └── di/
│       └── container.ts
├── presentation/                    # HTTP layer
│   ├── controllers/
│   │   └── TeamNeedsAnalysis.controller.ts
│   └── routes/
│       └── teamNeedsAnalysis.routes.ts
└── index.ts                        # Module bootstrap
```

## Key Features

### 1. Automated Roster Analysis
- Analyzes roster depth at every position
- Evaluates starter quality and backup depth
- Considers age, experience, performance grades
- Tracks contract situations and injury status

### 2. Intelligent Scoring System
- **Need Score (0-100)**: Composite metric based on:
  - Player count at position (30 points max)
  - Depth quality (25 points max)
  - Performance grades (20 points max)
  - Aging concerns (10 points max)
  - Contract expiry (10 points max)
  - Injury concerns (5 points max)

- **Priority (1-10)**: Weighted by position importance
  - QB, OL, DL: Highest importance (9-10)
  - WR, CB, TE, LB, S: Medium importance (6-8)
  - RB, K, P: Lower importance (2-5)

### 3. Data Sources
- **Primary**: `rosterPlayers` table (local MySQL data)
- **Optional**: ESPN API integration for live roster updates

## API Endpoints

### Generate Team Needs
```http
POST /api/team-needs/generate
Content-Type: application/json

{
  "teamId": 1,
  "seasonYear": 2025,
  "forceRefresh": false
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "teamId": 1,
    "seasonYear": 2025,
    "analysisDate": "2025-01-20T10:30:00Z",
    "overallNeedScore": 65,
    "topPriorities": ["OL", "CB", "WR"],
    "positionNeeds": [
      {
        "position": "OL",
        "positionGroup": "OL",
        "needScore": 85,
        "priority": 9,
        "reasoning": [
          "Only one player at position - critical depth issue",
          "Poor overall performance grades"
        ]
      }
    ],
    "metadata": {
      "rosterSize": 53,
      "averageAge": 26.5,
      "experienceLevel": 4.2,
      "injuryCount": 3
    }
  }
}
```

### Generate All Teams
```http
POST /api/team-needs/generate-all
Content-Type: application/json

{
  "seasonYear": 2025,
  "forceRefresh": false
}
```

### Get Team Needs
```http
GET /api/team-needs/1?seasonYear=2025
```

### Get All Teams (Season)
```http
GET /api/team-needs/season/2025
```

### DataTable Endpoints

**Teams Summary (for DataTable)**
```http
GET /api/team-needs/datatable/teams/2025
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "teamId": 1,
      "overallNeedScore": 65,
      "topNeeds": ["OL", "CB", "WR"],
      "criticalPositions": 3,
      "analysisDate": "2025-01-20T10:30:00Z"
    }
  ]
}
```

**Position Details (for detailed DataTable)**
```http
GET /api/team-needs/datatable/positions/2025
```

## Usage Examples

### Basic Integration

```typescript
import { PrismaClient } from '@prisma/client';
import { bootstrapTeamNeedsAnalysisModule } from './modules/teamNeedsAnalysis';

const prisma = new PrismaClient();
const teamNeedsRouter = bootstrapTeamNeedsAnalysisModule(prisma);

app.use('/api/team-needs', teamNeedsRouter);
```

### Direct Service Usage

```typescript
import { getTeamNeedsAnalysisContainer } from './modules/teamNeedsAnalysis';

const container = getTeamNeedsAnalysisContainer();
const service = container.getAnalysisService();

// Generate needs for a team
const analysis = await service.generateTeamNeeds(1, 2025);

// Get DataTable data
const tableData = await service.getTeamsNeedsDataTable(2025);
```

### Custom Repository Implementation

If you want to persist analysis results to MySQL instead of in-memory:

```typescript
// 1. Create a new Prisma model (add to schema.prisma):
model TeamNeedsAnalysis {
  id              Int       @id @default(autoincrement())
  teamId          Int
  seasonYear      Int
  analysisDate    DateTime
  analysisData    Json      // Store the entire analysis as JSON
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt
  
  @@unique([teamId, seasonYear])
  @@index([seasonYear])
}

// 2. Create PrismaTeamNeedsAnalysisRepository.ts:
export class PrismaTeamNeedsAnalysisRepository implements ITeamNeedsAnalysisRepository {
  constructor(private prisma: PrismaClient) {}
  
  async save(analysis: TeamNeedsAnalysis): Promise<TeamNeedsAnalysis> {
    const data = analysis.toJSON();
    
    await this.prisma.teamNeedsAnalysis.upsert({
      where: {
        teamId_seasonYear: {
          teamId: analysis.teamId,
          seasonYear: analysis.seasonYear
        }
      },
      create: {
        teamId: analysis.teamId,
        seasonYear: analysis.seasonYear,
        analysisDate: analysis.analysisDate,
        analysisData: data
      },
      update: {
        analysisDate: analysis.analysisDate,
        analysisData: data
      }
    });
    
    return analysis;
  }
  // ... implement other methods
}

// 3. Update container to use Prisma repository
```

## Frontend Integration

### Vue 3 + PrimeVue DataTable

```vue
<script setup lang="ts">
import { ref, onMounted } from 'vue';
import DataTable from 'primevue/datatable';
import Column from 'primevue/column';
import Button from 'primevue/button';
import { useToast } from 'primevue/usetoast';
import axios from 'axios';

const toast = useToast();
const loading = ref(false);
const teamNeeds = ref<any[]>([]);
const selectedYear = ref(2025);

const fetchTeamNeeds = async () => {
  loading.value = true;
  try {
    const response = await axios.get(`/api/team-needs/datatable/teams/${selectedYear.value}`);
    teamNeeds.value = response.data.data;
  } catch (error) {
    toast.add({
      severity: 'error',
      summary: 'Error',
      detail: 'Failed to load team needs',
      life: 3000
    });
  } finally {
    loading.value = false;
  }
};

const generateNeeds = async () => {
  loading.value = true;
  try {
    await axios.post('/api/team-needs/generate-all', {
      seasonYear: selectedYear.value,
      forceRefresh: true
    });
    
    toast.add({
      severity: 'success',
      summary: 'Success',
      detail: 'Team needs generated successfully',
      life: 3000
    });
    
    await fetchTeamNeeds();
  } catch (error) {
    toast.add({
      severity: 'error',
      summary: 'Error',
      detail: 'Failed to generate team needs',
      life: 3000
    });
  } finally {
    loading.value = false;
  }
};

onMounted(() => {
  fetchTeamNeeds();
});
</script>

<template>
  <div class="p-4">
    <div class="mb-4 flex justify-between items-center">
      <h1 class="text-2xl font-bold">Team Draft Needs - {{ selectedYear }}</h1>
      <Button 
        label="Generate Analysis" 
        icon="pi pi-refresh" 
        @click="generateNeeds"
        :loading="loading"
      />
    </div>

    <DataTable 
      :value="teamNeeds" 
      :loading="loading"
      stripedRows
      paginator
      :rows="10"
      sortField="overallNeedScore"
      :sortOrder="-1"
    >
      <Column field="teamId" header="Team ID" sortable />
      <Column field="overallNeedScore" header="Overall Need Score" sortable>
        <template #body="{ data }">
          <span :class="{
            'text-red-600 font-bold': data.overallNeedScore >= 70,
            'text-orange-600': data.overallNeedScore >= 50 && data.overallNeedScore < 70,
            'text-green-600': data.overallNeedScore < 50
          }">
            {{ data.overallNeedScore }}
          </span>
        </template>
      </Column>
      <Column field="topNeeds" header="Top Needs">
        <template #body="{ data }">
          <div class="flex gap-1">
            <span 
              v-for="need in data.topNeeds" 
              :key="need"
              class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium"
            >
              {{ need }}
            </span>
          </div>
        </template>
      </Column>
      <Column field="criticalPositions" header="Critical Positions" sortable />
      <Column field="analysisDate" header="Analysis Date">
        <template #body="{ data }">
          {{ new Date(data.analysisDate).toLocaleDateString() }}
        </template>
      </Column>
    </DataTable>
  </div>
</template>
```

## Dependency Injection

This module uses **manual dependency injection** without tsyringe:

```typescript
// Container manages all dependencies
const container = getTeamNeedsAnalysisContainer();

// Set shared dependencies
container.setPrismaClient(prisma);

// Retrieve dependencies
const service = container.getAnalysisService();
const controller = container.getController();

// Reset for testing
container.reset();
```

## Testing

```typescript
import { TeamNeedsAnalysisContainer } from './infrastructure/di/container';
import { PrismaClient } from '@prisma/client';

describe('TeamNeedsAnalysisService', () => {
  let container: TeamNeedsAnalysisContainer;
  let service: TeamNeedsAnalysisService;

  beforeEach(() => {
    container = new TeamNeedsAnalysisContainer();
    container.setPrismaClient(new PrismaClient());
    service = container.getAnalysisService();
  });

  afterEach(() => {
    container.reset();
  });

  it('should generate team needs', async () => {
    const result = await service.generateTeamNeeds(1, 2025);
    expect(result.teamId).toBe(1);
    expect(result.seasonYear).toBe(2025);
  });
});
```

## Database Requirements

The module requires the `rosterPlayers` table (already in your schema):

```sql
-- Ensure rosterPlayers has necessary data
SELECT COUNT(*) FROM rosterPlayers GROUP BY teamId;

-- Check data quality
SELECT teamId, COUNT(*) as player_count, 
       AVG(performanceGrade) as avg_grade
FROM rosterPlayers
GROUP BY teamId;
```

## Configuration

No configuration needed! The module is self-contained and uses your existing database schema.

## Future Enhancements

1. **Persist Analysis Results**: Add MySQL table to store analysis history
2. **ESPN Integration**: Automatically sync roster data from ESPN API
3. **Machine Learning**: Train models on historical draft success
4. **Position Flexibility**: Account for players who can play multiple positions
5. **Scheme Fit Analysis**: Evaluate needs based on team's offensive/defensive scheme

## Notes

- Analysis results are currently stored **in-memory** (cleared on server restart)
- For production, implement `PrismaTeamNeedsAnalysisRepository` to persist to MySQL
- The scoring algorithm can be tuned by adjusting weights in `RosterAnalyzerService`
- Position importance values can be customized in `TeamNeedsAnalysisService`
